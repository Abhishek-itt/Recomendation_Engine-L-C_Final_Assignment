#pragma once

#include <string>

class MealMenuResponseDTO
{
public:
    unsigned int mealMenuId;
    std::string userName;
    std::string response;
};