#pragma once

#include <string>

class RolloutMenuDTO {
public:
    unsigned int rolloutId;
    std::string date;
    std::string mealType;
    unsigned int foodId;
};