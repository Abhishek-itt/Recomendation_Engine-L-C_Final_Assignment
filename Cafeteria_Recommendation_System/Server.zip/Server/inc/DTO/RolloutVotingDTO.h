#pragma once

#include <string>

class RolloutVotingDTO {
public:
    unsigned int votingId;
    unsigned int rolloutId;
    std::string userName;
};