#pragma once
#include "RequestHandler/SocketServer.h"

#include "Utils/Serializar.h"

class ClientRequestHandler {
public:
    std::string HandleRequest(std::string requestBuffer);
private:

};