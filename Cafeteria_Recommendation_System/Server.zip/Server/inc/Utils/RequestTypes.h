#pragma once

enum class RequestType {
    USER_LOGIN,
    ADD_USER,
    ADD_FOOD_ITEM,
    DELETE_FOOD_ITEM,
    GET_FOOD_ITEM,
    GET_FOOD_ITEMS,
    ADD_FOOD_FEEDBACK,
    GET_FEEDBACKS_FOR_FOOD,
    LOGOUT,
};